{{/*
Observability Helm Chart - Helper Templates
Uses graph-olap-common library for standard templates.
*/}}

{{/*
Expand the name of the chart.
*/}}
{{- define "observability.name" -}}
{{- include "common.names.name" . }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "observability.chart" -}}
{{- include "common.names.chart" . }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "observability.labels" -}}
{{ include "common.labels.standard" . }}
{{- end }}
