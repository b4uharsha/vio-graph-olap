{{/*
Export Worker Helm Chart - Helper Templates
Uses graph-olap-common library for standard templates.
*/}}

{{/*
Expand the name of the chart.
*/}}
{{- define "export-worker.name" -}}
{{- include "common.names.name" . }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "export-worker.fullname" -}}
{{- include "common.names.fullname" . }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "export-worker.chart" -}}
{{- include "common.names.chart" . }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "export-worker.labels" -}}
{{ include "common.labels.standard" . }}
app: export-worker
component: export
{{- end }}

{{/*
Selector labels
*/}}
{{- define "export-worker.selectorLabels" -}}
{{ include "common.labels.matchLabels" . }}
app: export-worker
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "export-worker.serviceAccountName" -}}
{{- include "common.names.serviceAccountName" . }}
{{- end }}

{{/*
ConfigMap name
*/}}
{{- define "export-worker.configMapName" -}}
{{ include "export-worker.fullname" . }}-config
{{- end }}

{{/*
KEDA TriggerAuthentication name
*/}}
{{- define "export-worker.triggerAuthName" -}}
{{ include "export-worker.fullname" . }}-db-auth
{{- end }}
