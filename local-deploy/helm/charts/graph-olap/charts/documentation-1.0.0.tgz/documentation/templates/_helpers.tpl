{{/*
Documentation Helm Chart - Helper Templates
Uses graph-olap-common library for standard templates.
*/}}

{{/*
Expand the name of the chart.
*/}}
{{- define "documentation.name" -}}
{{- include "common.names.name" . }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "documentation.fullname" -}}
{{- include "common.names.fullname" . }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "documentation.chart" -}}
{{- include "common.names.chart" . }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "documentation.labels" -}}
{{ include "common.labels.standard" . }}
app: documentation
{{- end }}

{{/*
Selector labels
*/}}
{{- define "documentation.selectorLabels" -}}
{{ include "common.labels.matchLabels" . }}
app: documentation
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "documentation.serviceAccountName" -}}
{{- include "common.names.serviceAccountName" . }}
{{- end }}
